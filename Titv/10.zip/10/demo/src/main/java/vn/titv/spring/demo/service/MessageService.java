package vn.titv.spring.demo.service;

public interface MessageService {
    public String sendMessage();

}
