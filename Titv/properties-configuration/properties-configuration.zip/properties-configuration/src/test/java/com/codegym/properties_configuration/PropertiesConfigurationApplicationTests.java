package com.codegym.properties_configuration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertiesConfigurationApplicationTests {

	@Test
	void contextLoads() {
	}

}
