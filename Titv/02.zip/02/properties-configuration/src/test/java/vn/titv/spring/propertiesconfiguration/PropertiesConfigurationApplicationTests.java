package vn.titv.spring.propertiesconfiguration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertiesConfigurationApplicationTests {

	@Test
	void contextLoads() {
	}

}
